﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CSVExport;

namespace AVLTree
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
    public class AVL
    {
        
        class Node
        {
            public string data;
            public int num;
            public Node left;
            public Node right;
            
            public Node(string data, int num)
            {
                this.data = data;
                this.num = num;
            }
        }
        Node root;
        dynamic str;
        public AVL(string str)
        {
            this.str = str;
            List<string> lststr = new List<string>(str.Split(' '));
            foreach (string lstr in lststr)
            {
                this.Add(lstr, 1);
            }
        }
        public void Add(string data, int num)
        {
            Node newItem = new Node(data,num);
            if (root == null)
            {
                root = newItem;
            }
            else
            {
                root = RecursiveInsert(root, newItem);
            }
        }
        private Node RecursiveInsert(Node current, Node n)
        {
            if (current == null)
            {
                current = n;
                return current;
            }
            else if (String.Compare(n.data,current.data)<0)
            {
                current.left = RecursiveInsert(current.left, n);
                current = balance_tree(current);
            }
            else if (String.Compare(n.data,current.data)>0)
            {
                current.right = RecursiveInsert(current.right, n);
                current = balance_tree(current);
            }
            else if (String.Compare(n.data, current.data) == 0)
            {
                current.num = current.num + 1;
            }

                return current;
        }
        private Node balance_tree(Node current)
        {
            int b_factor = balance_factor(current);
            if (b_factor > 1)
            {
                if (balance_factor(current.left) > 0)
                {
                    current = RotateLL(current);
                }
                else
                {
                    current = RotateLR(current);
                }
            }
            else if (b_factor < -1)
            {
                if (balance_factor(current.right) > 0)
                {
                    current = RotateRL(current);
                }
                else
                {
                    current = RotateRR(current);
                }
            }
            return current;
        }
        private Node Find(string target, Node current)
        {

            if (string.Compare(target, current.data)<0)
            {
                if (target == current.data)
                {
                    return current;
                }
                else
                    return Find(target, current.left);
            }
            else
            {
                if (target == current.data)
                {
                    return current;
                }
                else
                    return Find(target, current.right);
            }

        }
        public void DisplayTree()
        {
            if (root == null)
            {
                Console.WriteLine("Tree is empty");
                return;
            }
            Console.Write("({0},{1})\n", "Data", "Count");
            InOrderDisplayTree(root);
            Console.WriteLine();
        }
        private void InOrderDisplayTree(Node current)
        {
            if (current != null)
            {
                InOrderDisplayTree(current.left);
                Console.Write("({0},{1})\n", current.data, current.num);
                InOrderDisplayTree(current.right);
            }
        }
        public void DisplayTreePrint()
        {
            if (root == null)
            {
                Console.WriteLine("Tree is empty");
                return;
            }
            InOrderDisplayTreePrint(root);
        }
        private void InOrderDisplayTreePrint(Node current)
        {
            if (current != null)
            {
                InOrderDisplayTreePrint(current.left);
                ToCSVExport.DatatableAddRow(current.data, current.num);
                InOrderDisplayTreePrint(current.right);
            }
        }
        private int max(int l, int r)
        {
            return l > r ? l : r;
        }
        private int getHeight(Node current)
        {
            int height = 0;
            if (current != null)
            {
                int l = getHeight(current.left);
                int r = getHeight(current.right);
                int m = max(l, r);
                height = m + 1;
            }
            return height;
        }
        private int balance_factor(Node current)
        {
            int l = getHeight(current.left);
            int r = getHeight(current.right);
            int b_factor = l - r;
            return b_factor;
        }
        private Node RotateRR(Node parent)
        {
            Node pivot = parent.right;
            parent.right = pivot.left;
            pivot.left = parent;
            return pivot;
        }
        private Node RotateLL(Node parent)
        {
            Node pivot = parent.left;
            parent.left = pivot.right;
            pivot.right = parent;
            return pivot;
        }
        private Node RotateLR(Node parent)
        {
            Node pivot = parent.left;
            parent.left = RotateRR(pivot);
            return RotateLL(parent);
        }
        private Node RotateRL(Node parent)
        {
            Node pivot = parent.right;
            parent.right = RotateLL(pivot);
            return RotateRR(parent);
        }
    }
}