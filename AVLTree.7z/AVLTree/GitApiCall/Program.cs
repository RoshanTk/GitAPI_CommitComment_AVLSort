﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using Octokit;
using System.Collections.ObjectModel;
using AVLTree;
using System.Data;
using CSVExport;

namespace GitApiCall
{
    class Program
    {
        private static readonly string GitHubIdentity = Assembly
            .GetEntryAssembly()
            .GetCustomAttribute<AssemblyProductAttribute>()
            .Product;
        static void Main(string[] args)
        {
            try
            {
                var productInformation = new ProductHeaderValue(GitHubIdentity);
                if (!TryGetClient(args, productInformation, out GitHubClient client))
                    return;

                TestFeature(client)
                    .GetAwaiter()
                    .GetResult();
            }
            catch(Exception ex)
            {
                Console.Write("Please input valid entry");
                Console.ReadLine();
            }
        }

        private static GitHubClient GetClient(ProductHeaderValue productInformation, string token)
        {
                var credentials = new Credentials(token);
                var client = new GitHubClient(productInformation) { Credentials = credentials };

                return client;
        }

        private static async Task RepositoryExamples(GitHubClient client, string uName, string gRepo)
        {
            List<GitHubCommit> listgitHubCommit = new List<GitHubCommit>(await client.Repository.Commit.GetAll(uName, gRepo));

            foreach (var gitHubCommit in listgitHubCommit)
            {
                List<CommitComment> LocallistCommitComment = new List<CommitComment>(await client.Repository.Comment.GetAllForCommit(uName, gRepo, gitHubCommit.Sha));
                foreach (var localgitHubCommit in LocallistCommitComment)
                {
                    Console.WriteLine(localgitHubCommit.Body);
                    AVLTree.AVL tree = new AVLTree.AVL(localgitHubCommit.Body.ToString());
                    tree.DisplayTree();
                }
            }
        }

        private static async Task RepositoryPrint(GitHubClient client, string uName, string gRepo)
        {
            List<GitHubCommit> listgitHubCommit = new List<GitHubCommit>(await client.Repository.Commit.GetAll(uName, gRepo));

            foreach (var gitHubCommit in listgitHubCommit)
            {
                List<CommitComment> LocallistCommitComment = new List<CommitComment>(await client.Repository.Comment.GetAllForCommit(uName, gRepo, gitHubCommit.Sha));
                foreach (var localgitHubCommit in LocallistCommitComment)
                {
                    AVLTree.AVL tree = new AVLTree.AVL(localgitHubCommit.Body.ToString());
                    tree.DisplayTreePrint();
                }
            }
        }

        private static GitHubClient AuthenticateToken(string[] args, ProductHeaderValue productionInformation)
        {
            string token;
            if (args.Length > 1)
                token = args[1];
            else
            {
                Console.Write("OAuth Token? ");
                token = Console.ReadLine();
            }

            return GetClient(productionInformation, token);
        }

        private static bool IsAltOrControl(ConsoleKeyInfo keyInfo) =>
            (keyInfo.Modifiers & (ConsoleModifiers.Alt | ConsoleModifiers.Control)) != 0;

        private static bool TryGetClient(string[] args, ProductHeaderValue productionInformation, out GitHubClient client)
        {
            if (args.Length > 0 && args[0].Length > 0)
                return TryGetClient(args, args[0][0], productionInformation, out client);

            while (true)
            {
                if (!TryReadAuthenticationKey(out char key))
                    continue;

                if (key == (char)ConsoleKey.Escape)
                {
                    client = null;
                    return false;
                }

                if (TryGetClient(args, key, productionInformation, out client))
                    return true;
            }
        }

        private static bool TryGetClient(string[] args, char chr, ProductHeaderValue productionInformation, out GitHubClient client)
        {
            switch (chr)
            {
                /*case 'b':
				case 'B':
					client = AuthenticateBasic(args, productionInformation);
					return client != null;*/

                case 't':
                case 'T':
                    client = AuthenticateToken(args, productionInformation);
                    return client != null;

                /*case 'u':
				case 'U':
					client = new GitHubClient(productionInformation);
					return client != null;*/

                default:
                    Console.WriteLine($"Invalid authentication type.");
                    client = null;
                    return false;
            }
        }

        private static bool TryReadAuthenticationKey(out char result)
        {
            Console.Write("Authentication (T=Token, Esc=Exit)? ");
            ConsoleKeyInfo keyInfo = Console.ReadKey();
            Console.WriteLine();

            if (IsAltOrControl(keyInfo))
            {
                result = (char)0;
                return false;
            }

            result = keyInfo.KeyChar;
            return true;
        }

        private static async Task TestFeature(GitHubClient client)
        {
            Console.WriteLine();
            Console.Write("User Name ? ");
            string uName = Console.ReadLine();
            Console.WriteLine();
            Console.Write("GHE repo ? ");
            string gRepo = Console.ReadLine();
            Console.WriteLine();
            Console.WriteLine("Press following");
            Console.WriteLine(" R=Repository");
            Console.WriteLine(" Esc=Exit");
            while (true)
            {
                ConsoleKeyInfo keyInfo = Console.ReadKey();
                Console.WriteLine();

                if (IsAltOrControl(keyInfo))
                    continue;

                switch (keyInfo.Key)
                {
                    case ConsoleKey.R:
                        Console.WriteLine();
                        Console.WriteLine("Connecting Repository for Commit Comments...");
                        Console.WriteLine();
                        await RepositoryExamples(client, uName, gRepo);
                        Console.Write("Do you want to download in csv format (Y/N) ? ");
                        ConsoleKeyInfo keyInf = Console.ReadKey();
                        Console.WriteLine();
                        switch (keyInf.Key)
                        {
                            case ConsoleKey.N:
                                System.Environment.Exit(0);
                                break;

                            case ConsoleKey.Y:
                                Console.Write("File save location ? ");
                                string strFilePath = Console.ReadLine();

                                ToCSVExport.Datatableobject();
                                await RepositoryPrint(client, uName, gRepo);
                                try
                                {
                                    ToCSVExport.ToCSV(strFilePath);
                                }
                                catch(Exception ex)
                                {
                                    Console.Write(ex.Message);
                                }
                                break;
                        }
                       
                        break;

                    case ConsoleKey.Escape:
                        return;

                    default:
                        Console.WriteLine("Invalid selection.");
                        System.Environment.Exit(0);
                        break;
                }
            }
        }
    }
}
